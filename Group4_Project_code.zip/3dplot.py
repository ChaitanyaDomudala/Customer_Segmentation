import numpy as np
import pandas as pd
import matplotlib.pyplot as plt, mpld3
from sklearn.cluster import KMeans
from mpl_toolkits.mplot3d import Axes3D

cust = pd.read_csv(
    'https://s3-api.us-geo.objectstorage.softlayer.net/cf-courses-data/CognitiveClass/ML0101ENv3/labs'
    '/Cust_Segmentation.csv')
cust.head()

cust.shape
cust.drop(['Address'], axis=1, inplace=True)

print(cust.shape)
cust.head()

from sklearn.preprocessing import StandardScaler

X = cust.values[:, 1:]
X = np.nan_to_num(X)
Clus_dataSet = StandardScaler().fit_transform(X)
Clus_dataSet

clusterNum = 3
k_means = KMeans(init="k-means++", n_clusters=clusterNum, n_init=12)
k_means.fit(X)
labels = k_means.labels_
print(labels)

cust["Clus_km"] = labels
cust.head(5)

cust.groupby('Clus_km').mean()

fig = plt.figure(1, figsize=(8, 6))
plt.clf()
ax = Axes3D(fig, rect=[0, 0, .95, 1], elev=48, azim=134)

plt.cla()
# plt.ylabel('Age', fontsize=18)
# plt.xlabel('Income', fontsize=16)
# plt.zlabel('Education', fontsize=16)
ax.set_xlabel('Education')
ax.set_ylabel('Age')
ax.set_zlabel('Income')

ax.scatter(X[:, 1], X[:, 0], X[:, 3], c=labels.astype(np.float))
plt.savefig('foo.png')
again = mpld3.fig_to_html(fig)
print(again)
