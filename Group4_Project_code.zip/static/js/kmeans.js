function plotGraph() {
    clusternum = $('#clusternum')[0].value;
    let filePath = $('#filepath').prop('files')[0];
    if (filePath === undefined) {
        alert('No file selected');
        return;
    } else if (!filePath.name.endsWith('csv')) {
        alert('Not a valid file');
        return;
    }
    validateHeader(filePath);
}

function threedPlot() {
    // $.ajax({
    //     type: 'GET',
    //     url: '/plotthreed',
    //     async: true,
    //     success: function (data) {
    //         // $('#imagediv').html('<img src="' +'data:image/png;base64,'+ data + '"/>');
    //     }
    // });

}

function validateHeader(file) {
    var allKeyPresent = false; // Flag

    Papa.parse(file, {
        header: true,
        skipEmptyLines: true,
        step: function (row, parser) {
            if (!allKeyPresent) { //Only chek if flag is not set, i.e, for the first time
                parser.pause(); // pause the parser
                var first_row_data = row.data[0];
                // Now check object keys, if it match
                if (('Customer Id' in first_row_data) && ('Age' in first_row_data) && ('Edu' in first_row_data)
                    && ('Years Employed' in first_row_data)
                    && ('Income' in first_row_data)
                    && ('Card Debt' in first_row_data)
                    && ('Other Debt' in first_row_data)
                    && ('Defaulted' in first_row_data)
                    && ('DebtIncomeRatio' in first_row_data)
                    && ('Address' in first_row_data)) {
                    //every required key is present
                    allKeyPresent = true;

                    var form_data = new FormData();
                    form_data.append('file', $('#filepath').prop('files')[0]);
                    $.ajax({
                        url: '/plot/' + clusternum,
                        data: form_data,
                        contentType: false,
                        cache: false,
                        processData: false,
                        type: 'POST',
                        success: function (response) {
                            $("#recomdiv").html(response);
                            $('#imagediv').html('<img id="theImg" />');
                            $('#theImg').attr("src", "http://127.0.0.1:5000/plotthreed?timestamp=" + new Date().getTime());
                        },
                        error: function (error) {
                            console.log(error);
                        }
                    });
                    threedPlot();
                    parser.resume();
                } else {
                    //some key is missing, abort parsing
                    parser.abort();
                    alert('Please check your csv again. Some keys are missing');
                }

            } else { // we already match the header, all required key is present

                // Do the Data processing here

            }

        }
    });

    return allKeyPresent;

}